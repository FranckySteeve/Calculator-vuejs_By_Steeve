<template>
  <div class="front">
    <front/>

  </div>
</template>

<script>
import front from './components/calculatrice.vue'
  export default {
    components: {
      front
    }
  }
</script>